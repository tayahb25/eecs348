package com.example.lab6eecs3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab6eecs3ApplicationTests {

    @Test
    void contextLoads() {
    }

}
