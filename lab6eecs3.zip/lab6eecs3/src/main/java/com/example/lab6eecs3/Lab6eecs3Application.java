package com.example.lab6eecs3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab6eecs3Application {

    public static void main(String[] args) {
        SpringApplication.run(Lab6eecs3Application.class, args);
    }

}
